## Query to insert different types of parks
SELECT	st_transform(way, 4326)
FROM	planet_osm_polygon
WHERE	leisure in ('park', 'dog_park')
ORDER BY area DESC;

Query to find New York City
SELECT	*
FROM	planet_osm_polygon
WHERE	place = 'city'
and name = 'City of New York'
ORDER BY name;


##Query to explore different fields like (place) on the table
SELECT	DISTINCT place
FROM	planet_osm_polygon
ORDER BY place;

##Query to explore different fields like (admin level) on the table
SELECT	DISTINCT admin_level
FROM	planet_osm_polygon
ORDER BY admin_level;

##Query to explore different fields like (different kinds of leisure) on the table
SELECT	DISTINCT leisure
FROM	planet_osm_polygon
ORDER BY leisure;


## Query to create table for green spaces
CREATE TABLE green_spaces (
id SERIAL PRIMARY KEY,
name VARCHAR(255),
location GEOMETRY(Point, 3857),
area_sq_m NUMERIC
	);
## Query to insert diferent types of parks 	
INSERT INTO green_spaces (name, location, area_sq_m)
SELECT name, ST_Centroid(way), ST_Area(way)
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park')

## Query to find he total number of parks, total area covered by parks, and average park size
SELECT COUNT(*) AS total_parks, SUM(area_sq_m) AS total_area, AVG(area_sq_m)
FROM green_spaces;

## Query to select total area of green spaces
SELECT SUM(ST_Area(way)) as total_green_space_area
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park');

## Query to find the Top 5 Largest Green Spaces
SELECT name, ST_Area(way) as area
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park')
ORDER BY area DESC
LIMIT 5;