SELECT	st_transform(way, 4326)
FROM	planet_osm_polygon
WHERE	leisure in ('park', 'dog_park')
ORDER BY area DESC;

SELECT	*
FROM	planet_osm_polygon
WHERE	place = 'city'
and name = 'City of New York'
ORDER BY name;


SELECT	*
FROM	planet_osm_polygon
ORDER BY area DESC;

SELECT	DISTINCT place
FROM	planet_osm_polygon
ORDER BY place;


SELECT	DISTINCT admin_level
FROM	planet_osm_polygon
ORDER BY admin_level;

SELECT	DISTINCT leisure
FROM	planet_osm_polygon
ORDER BY leisure;

SELECT	*
FROM	planet_osm_polygon
WHERE	UPPER(name)	LIKE	'%TEXT%'
ORDER BY place;


CREATE TABLE green_spaces (
id SERIAL PRIMARY KEY,
name VARCHAR(255),
location GEOMETRY(Point, 3857),
area_sq_m NUMERIC
	);
	
INSERT INTO green_spaces (name, location, area_sq_m)
SELECT name, ST_Centroid(way), ST_Area(way)
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park')


SELECT COUNT(*) AS total_parks, SUM(area_sq_m) AS total_area, AVG(area_sq_m)
FROM green_spaces;

SELECT SUM(ST_Area(way)) as total_green_space_area
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park');

SELECT name, ST_Area(way) as area
FROM planet_osm_polygon
WHERE leisure in ('park', 'dog_park')
ORDER BY area DESC
LIMIT 5;